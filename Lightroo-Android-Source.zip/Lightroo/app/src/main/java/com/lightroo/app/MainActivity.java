package com.lightroo.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;
import android.os.Looper;

public class MainActivity extends Activity {
    private CameraManager cameraManager;
    private String cameraId;
    private boolean torchOn = false;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable patternRunnable;
    private boolean patternRunning = false;
    private int patternStep = 0;
    private int selectedPattern = 0;
    private Button[] buttons = new Button[6];
    private TextView status;

    private final int[][] patterns = {
        {0},                         // steady toggle
        {1,0,1,0,1,0,0,0},           // 3 flashes
        {1,0,0,1,0,0},               // double flash
        {1,0,1,0,0,0},               // quick strobe
        {1,0,0,0,1,0,0,0},           // slow pulse
        {1,0,1,0,1,0,1,0,0,0}        // four flashes
    };
    private final long[] delays = {500, 180, 280, 100, 650, 130};

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            for (String id : cameraManager.getCameraIdList()) {
                Boolean flash = cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(flash)) { cameraId = id; break; }
            }
        } catch (Exception ignored) {}

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(16,16,26));

        TextView title = new TextView(this);
        title.setText("LIGHTROO");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.12f);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(58)));

        TextView subtitle = new TextView(this);
        subtitle.setText("FLASH • DJ PATTERNS");
        subtitle.setTextColor(Color.rgb(177,160,255));
        subtitle.setTextSize(13);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(32)));

        status = new TextView(this);
        status.setText("● FLASH OFF");
        status.setTextColor(Color.rgb(190,190,205));
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(52));
        sp.bottomMargin = dp(14);
        root.addView(status, sp);

        String[] labels = {"1  •  ON / OFF", "2  •  TRIPLE FLASH", "3  •  DOUBLE FLASH",
                           "4  •  QUICK STROBE", "5  •  SLOW PULSE", "6  •  DJ BURST"};
        for (int i=0; i<6; i++) {
            final int index = i;
            Button b = new Button(this);
            buttons[i] = b;
            b.setText(labels[i]);
            b.setTextSize(14);
            b.setAllCaps(false);
            b.setTextColor(Color.WHITE);
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                i == 0 ? Color.rgb(111,70,220) : Color.rgb(42,42,65)));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(58));
            bp.bottomMargin = dp(10);
            root.addView(b, bp);
            b.setOnClickListener(v -> onPatternClick(index));
        }

        TextView note = new TextView(this);
        note.setText("Use only when safe. Flash patterns may affect people sensitive to flashing lights.");
        note.setTextColor(Color.rgb(160,160,175));
        note.setTextSize(11);
        note.setGravity(Gravity.CENTER);
        root.addView(note, new LinearLayout.LayoutParams(-1, dp(48)));

        setContentView(root);
        if (cameraId == null) {
            status.setText("No compatible flash found");
            for (Button b : buttons) b.setEnabled(false);
        }
    }

    private void onPatternClick(int index) {
        if (cameraId == null) return;
        if (index == 0) {
            stopPattern();
            setTorch(!torchOn);
            return;
        }
        if (patternRunning && selectedPattern == index) {
            stopPattern();
            setTorch(false);
            return;
        }
        stopPattern();
        selectedPattern = index;
        patternRunning = true;
        patternStep = 0;
        runPattern(index);
    }

    private void runPattern(int index) {
        if (!patternRunning || selectedPattern != index) return;
        int[] p = patterns[index];
        int value = p[patternStep % p.length];
        setTorch(value == 1);
        patternStep++;
        patternRunnable = () -> runPattern(index);
        handler.postDelayed(patternRunnable, delays[index]);
    }

    private void stopPattern() {
        patternRunning = false;
        if (patternRunnable != null) handler.removeCallbacks(patternRunnable);
        patternRunnable = null;
    }

    private void setTorch(boolean on) {
        try {
            cameraManager.setTorchMode(cameraId, on);
            torchOn = on;
            status.setText(on ? "● FLASH ON" : "● FLASH OFF");
            status.setTextColor(on ? Color.rgb(255,205,80) : Color.rgb(190,190,205));
        } catch (CameraAccessException | IllegalArgumentException e) {
            Toast.makeText(this, "Flashlight busy or unavailable", Toast.LENGTH_SHORT).show();
        }
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onPause() {
        super.onPause();
        stopPattern();
        if (cameraId != null) setTorch(false);
    }
    @Override protected void onDestroy() {
        stopPattern();
        if (cameraId != null) setTorch(false);
        super.onDestroy();
    }
}
